// File: src/IndianPlayers.js
import React from 'react';

const IndianPlayers = () => {
  const oddPlayers = ['Sachin1', 'Virat3', 'Yuvaraj5'];
  const evenPlayers = ['Dhoni2', 'Rohit4', 'Raina6'];
  const mergedPlayers = ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth'];

  return (
    <div>
      <h1>Odd Players</h1>
      <ul>
        {oddPlayers.map((name, index) => (
          <li key={index}>
            {index === 0 ? 'First' : index === 1 ? 'Third' : 'Fifth'} : {name}
          </li>
        ))}
      </ul>
      <h1>Even Players</h1>
      <ul>
        {evenPlayers.map((name, index) => (
          <li key={index}>
            {index === 0 ? 'Second' : index === 1 ? 'Fourth' : 'Sixth'} : {name}
          </li>
        ))}
      </ul>
      <h1>Merged Players</h1>
      <ul>
        {mergedPlayers.map((player, index) => (
          <li key={index}>Mr. {player} Player</li>
        ))}
      </ul>
    </div>
  );
};

export default IndianPlayers;
