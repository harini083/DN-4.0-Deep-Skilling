import React from 'react';
import './App.css';
import officeImage from './office.jpg.jpeg';

function App() {
  const heading = "Office Space";
  const office = {
    Name: "DBS",
    Rent: 50000,
    Address: "Chennai",
    Image: officeImage

  };

  // Conditional color style for rent
  const rentStyle = {
    color: office.Rent <= 60000 ? 'red' : 'green',
    fontWeight: 'bold'
  };

  return (
    <div className="container">
      <h1>{heading},at Affordable Range
        </h1>
      <img src={officeImage} alt="Office" className="office-image" />
      <h3 className="name">Name: DBS</h3>

      <p className="rent">Rent: Rs. 50000</p>
      <p className="address">Address: Chennai</p>
    </div>
  );
}

export default App;
