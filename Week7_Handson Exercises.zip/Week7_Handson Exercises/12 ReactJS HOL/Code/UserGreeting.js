import React from 'react';

function UserGreeting() {
  return <h2>Welcome back, user! You can now book tickets.</h2>;
}

export default UserGreeting;
