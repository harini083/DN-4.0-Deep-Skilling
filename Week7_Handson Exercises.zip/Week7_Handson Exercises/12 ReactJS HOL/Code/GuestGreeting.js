import React from 'react';

function GuestGreeting() {
  return <h2>Welcome, guest! Please log in to book tickets.</h2>;
}

export default GuestGreeting;
