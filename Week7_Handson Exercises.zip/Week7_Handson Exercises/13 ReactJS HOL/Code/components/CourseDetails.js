import React from 'react';

const CourseDetails = ({ show }) => {
  // Conditional Rendering: Using Logical AND &&
  return show && (
    <div style={{ borderRight: '2px solid green', padding: '0 20px' }}>
      <h3>Course Details</h3>
      <p>Angular</p>
      <p>1/8/2025</p>
      <p>React</p>
      <p>2/8/2025</p>
    </div>
  );
};

export default CourseDetails;
