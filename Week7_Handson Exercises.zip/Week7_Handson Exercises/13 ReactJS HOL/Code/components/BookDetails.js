import React from 'react';

const BookDetails = ({ show }) => {
  // Conditional Rendering: Using Ternary Operator
  return (
    <>
      {show ? (
        <div style={{ borderRight: '2px solid green', padding: '0 20px' }}>
          <h3>Book Details</h3>
          <p>Master React</p>
          <p>670</p>
          <p>Deep Dive into Angular 11</p>
          <p>800</p>
          <p>Mongo Essentials</p>
          <p>450</p>
        </div>
      ) : null}
    </>
  );
};

export default BookDetails;
