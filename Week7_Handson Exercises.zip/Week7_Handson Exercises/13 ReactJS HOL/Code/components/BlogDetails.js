import React from 'react';

function BlogDetails({ show }) {
  // Conditional Rendering: Using if-else inside function body
  if (!show) return null;

  return (
    <div style={{ padding: '0 20px' }}>
      <h3>Blog Details</h3>
      <p>React Learning</p>
      <p><strong>Stephen Biz</strong></p>
      <p>Welcome to learning React!</p>
      
      
    </div>
  );
}

export default BlogDetails;
