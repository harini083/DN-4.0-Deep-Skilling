import React from 'react';
import './App.css';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';

function App() {
  const showCourses = true;
  const showBooks = true;
  const showBlogs = true;

  return (
    <div className="App">
      <h1>React App</h1>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <CourseDetails show={showCourses} />
        <BookDetails show={showBooks} />
        <BlogDetails show={showBlogs} />
      </div>
    </div>
  );
}

export default App;
