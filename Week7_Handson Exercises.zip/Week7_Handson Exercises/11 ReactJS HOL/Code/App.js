import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const [amountInINR, setAmountInINR] = useState('');
  const [convertedAmount, setConvertedAmount] = useState(null);
  const euroRate = 90; // 1 Euro = 90 INR

  const sayWelcome = (msg) => {
    alert("localhost:3000 says\n" + msg);
  };

  const handleClick = () => {
    alert("Hello! You clicked the button.");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const converted = (parseFloat(amountInINR) / euroRate).toFixed(2);
    setConvertedAmount(converted);
  };

  const handleSyntheticEvent = () => {
    alert("I was clicked");
  };

  return (
    <div style={{ margin: '30px', fontFamily: 'Arial' }}>
      <h2>{count}</h2>
      <button onClick={() => {
        setCount(count + 1);
        console.log("Saying hello...");
        alert("Hello! Value increased.");
      }}>
        Increment
      </button>{' '}
      <button onClick={() => setCount(count - 1)}>Decrement</button>{' '}
      <button onClick={() => sayWelcome("welcome")}>Say welcome</button>{' '}
      <button onClick={handleClick}>Click on me</button>

      <br /><br />
      <h2 style={{ color: "green" }}>Currency Convertor</h2>
      <form onSubmit={handleSubmit}>
        <label>Amount in INR: </label>
        <input
          type="text"
          value={amountInINR}
          onChange={(e) => setAmountInINR(e.target.value)}
          required
        />
        <br /><br />
        <button type="submit">Convert to Euro</button>
      </form>

      {convertedAmount !== null && (
        <div style={{ marginTop: '10px', fontWeight: 'bold' }}>
          Total in Euro: € {convertedAmount}
        </div>
      )}

      <br />
      <button onClick={handleSyntheticEvent}>OnPress</button>
    </div>
  );
}

export default App;
