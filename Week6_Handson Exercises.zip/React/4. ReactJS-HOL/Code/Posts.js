import React from 'react';

class Posts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: [
        {
          id: 1,
          title: 'My Favorite Animal: Dolphin',
          body: 'Dolphins are intelligent and friendly marine mammals. They communicate using clicks and whistles, and they’re known for their playful behavior.'
        },
        {
          id: 2,
          title: 'Why I Love the Planet Mars',
          body: 'Mars is known as the Red Planet and is the most explored planet after Earth. Its mysterious terrain, potential for life, and possibility of future colonization fascinate me.'
        }
      ]
    };
  }

  render() {
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <h1>My Blog Posts</h1>
        {this.state.posts.map(post => (
          <div key={post.id} style={{ marginBottom: '20px', borderBottom: '1px solid #ccc', paddingBottom: '10px' }}>
            <h2>{post.title}</h2>
            <p>{post.body}</p>
          </div>
        ))}
      </div>
    );
  }
}

export default Posts;
