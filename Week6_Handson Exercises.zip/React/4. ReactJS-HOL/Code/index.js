import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css'; // You can delete or comment this line if you're not using index.css
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


