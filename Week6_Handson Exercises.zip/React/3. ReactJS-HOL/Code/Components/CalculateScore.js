import React from 'react';
import '../Stylesheets/mystyle.css'; // ✅ if called from App.js

export function CalculateScore(props) {
  return (
    <div className="Score">
      <h2>Name: {props.Name}</h2>
      <h3>School: {props.School}</h3>
      <p>Total Score: {props.total}</p>
      <p>Goal: {props.goal}</p>
    </div>
  );
}
