import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        // Sample product list
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shoes", "Footwear"),
            new Product(103, "T-Shirt", "Clothing"),
            new Product(104, "Smartphone", "Electronics"),
            new Product(105, "Blender", "Kitchen")
        };

        // Search for a product that does NOT exist
        String searchTarget = "Laptop";

        // Perform linear search
        System.out.println("🔍 Linear Search:");
        int linearIndex = SearchAlgorithms.linearSearch(products, searchTarget);
        if (linearIndex != -1) {
            System.out.println("Product found at index " + linearIndex + ": " + products[linearIndex]);
        } else {
            System.out.println("Product not found.");
        }

        // Sort products by productName before binary search
        Arrays.sort(products, Comparator.comparing(p -> p.productName));

        // Perform binary search
        System.out.println("\n🔍 Binary Search:");
        int binaryIndex = SearchAlgorithms.binarySearch(products, searchTarget);
        if (binaryIndex != -1) {
            System.out.println("Product found at index " + binaryIndex + ": " + products[binaryIndex]);
        } else {
            System.out.println("Product not found.");
        }
    }
}
