public class FinancialForecast {

    // Recursive method to calculate future value
    public static double predictFutureValueRecursive(double currentValue, double growthRate, int years) {
        if (years == 0) {
            return currentValue;
        }
        return predictFutureValueRecursive(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    // Iterative method to calculate future value
    public static double predictFutureValueIterative(double currentValue, double growthRate, int years) {
        for (int i = 0; i < years; i++) {
            currentValue *= (1 + growthRate);
        }
        return currentValue;
    }

    public static void main(String[] args) {
        double initialValue = 10000.0; // starting amount
        double growthRate = 0.08;      // 8% annual growth
        int years = 5;                 // number of years

        double recursiveResult = predictFutureValueRecursive(initialValue, growthRate, years);
        double iterativeResult = predictFutureValueIterative(initialValue, growthRate, years);

        // Output both results
        System.out.printf("Recursive Future Value after %d years: ₹%.2f%n", years, recursiveResult);
        System.out.printf("Iterative Future Value after %d years: ₹%.2f%n", years, iterativeResult);
    }
}

