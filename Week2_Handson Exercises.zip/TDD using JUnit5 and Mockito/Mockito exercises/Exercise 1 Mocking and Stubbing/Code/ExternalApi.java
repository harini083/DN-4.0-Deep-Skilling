package com.example.Mockitodemo;

/**
 * Hello world!
 */
public interface ExternalApi {
    String getData();
}
