package com.example.verifying;

/**
 * Hello world!
 */
public interface ExternalApi {
    String getData();

}
