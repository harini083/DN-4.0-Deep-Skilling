package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class SimpleMathTest {

    private SimpleMath math;

    @BeforeEach
    public void setUp() {
        math = new SimpleMath();
        System.out.println("Before each test");
    }

    @AfterEach
    public void tearDown() {
        System.out.println("After each test\n");
    }

    @Test
    public void testMultiply() {
        int result = math.multiply(3, 4);
        System.out.println("Multiply result: " + result);
        assertEquals(12, result);
    }

    @Test
    public void testIsEven() {
        boolean result = math.isEven(8);
        System.out.println("IsEven result: " + result);
        assertTrue(result);
    }

    @Test
    public void testSubtraction() {
        int result = math.subtract(10, 4);
        assertEquals(6, result);
    }
}
