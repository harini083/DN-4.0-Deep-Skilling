package com.example.project;

/**
 * Hello world!
 */


public class SimpleMath {

    public int multiply(int a, int b) {
        return a * b;
    }

    public boolean isEven(int n) {
        return n % 2 == 0;
    }
    public int subtract(int a, int b) {
        return a - b;
    }
}


