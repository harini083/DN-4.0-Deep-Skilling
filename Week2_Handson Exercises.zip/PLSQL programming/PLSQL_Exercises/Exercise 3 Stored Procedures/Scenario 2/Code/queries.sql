-- Drop and create Employees table
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Employees';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE Employees (
    EmpID NUMBER PRIMARY KEY,
    Name VARCHAR2(50),
    Department VARCHAR2(50),
    Salary NUMBER
);

-- Sample data
BEGIN
  INSERT INTO Employees VALUES (101, 'Alice', 'HR', 50000);
  INSERT INTO Employees VALUES (102, 'Bob', 'IT', 60000);
  INSERT INTO Employees VALUES (103, 'Charlie', 'IT', 55000);
END;
/

-- Procedure: UpdateEmployeeBonus
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(
  p_dept IN VARCHAR2,
  p_bonus_percent IN NUMBER
) IS
BEGIN
  FOR emp IN (SELECT EmpID, Salary FROM Employees WHERE Department = p_dept) LOOP
    UPDATE Employees
    SET Salary = Salary + (emp.Salary * p_bonus_percent / 100)
    WHERE EmpID = emp.EmpID;

    DBMS_OUTPUT.PUT_LINE('Bonus applied to EmpID ' || emp.EmpID);
  END LOOP;
END;
/

-- Call the procedure for IT department with 10% bonus
BEGIN
  UpdateEmployeeBonus('IT', 10);
END;
/

BEGIN
  DBMS_OUTPUT.PUT_LINE(RPAD('EmpID', 8) || RPAD('Name', 15) || RPAD('Department', 15) || RPAD('Salary', 10));
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

  FOR emp IN (SELECT * FROM Employees ORDER BY EmpID) LOOP
    DBMS_OUTPUT.PUT_LINE(
      RPAD(emp.EmpID, 8) ||
      RPAD(emp.Name, 15) ||
      RPAD(emp.Department, 15) ||
      RPAD(emp.Salary, 10)
    );
  END LOOP;
END;
/
