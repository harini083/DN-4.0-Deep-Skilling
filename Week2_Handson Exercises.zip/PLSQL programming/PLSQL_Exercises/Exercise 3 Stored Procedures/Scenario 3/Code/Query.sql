-- Drop Accounts table if it exists
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Accounts';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- Create Accounts table
CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    AccountHolder VARCHAR2(50),
    Balance NUMBER
);

-- Insert sample accounts
BEGIN
  INSERT INTO Accounts VALUES (1, 'Alice', 10000);
  INSERT INTO Accounts VALUES (2, 'Bob', 8000);
  INSERT INTO Accounts VALUES (3, 'Charlie', 5000);
END;
/

-- Stored Procedure: TransferFunds
CREATE OR REPLACE PROCEDURE TransferFunds(
  p_from_acct IN NUMBER,
  p_to_acct IN NUMBER,
  p_amount IN NUMBER
) IS
  v_balance NUMBER;
BEGIN
  -- Get balance of source account
  SELECT Balance INTO v_balance FROM Accounts WHERE AccountID = p_from_acct;

  -- Check for sufficient balance
  IF v_balance < p_amount THEN
    RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance in source account.');
  END IF;

  -- Deduct from source account
  UPDATE Accounts
  SET Balance = Balance - p_amount
  WHERE AccountID = p_from_acct;

  -- Add to destination account
  UPDATE Accounts
  SET Balance = Balance + p_amount
  WHERE AccountID = p_to_acct;

  DBMS_OUTPUT.PUT_LINE('Transferred Rs.' || p_amount || 
                       ' from Account ' || p_from_acct || 
                       ' to Account ' || p_to_acct);
END;
/

-- Call the procedure: Transfer ₹2000 from Account 1 to Account 3
BEGIN
  TransferFunds(1, 3, 2000);
END;
/

-- ✅ Display formatted account balances
BEGIN
  DBMS_OUTPUT.PUT_LINE(RPAD('AccountID', 12) || RPAD('AccountHolder', 20) || RPAD('Balance', 10));
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 45, '-'));

  FOR acc IN (SELECT * FROM Accounts ORDER BY AccountID) LOOP
    DBMS_OUTPUT.PUT_LINE(
      RPAD(acc.AccountID, 12) ||
      RPAD(acc.AccountHolder, 20) ||
      RPAD(acc.Balance, 10)
    );
  END LOOP;
END;
/
