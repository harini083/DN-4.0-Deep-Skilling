-- Drop and create Accounts table
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Accounts';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    AccountType VARCHAR2(20), -- e.g., 'Savings', 'Checking'
    Balance NUMBER
);

-- Sample data
BEGIN
  INSERT INTO Accounts VALUES (1, 'Savings', 10000);
  INSERT INTO Accounts VALUES (2, 'Savings', 15000);
  INSERT INTO Accounts VALUES (3, 'Checking', 8000);
END;
/

-- Procedure: ProcessMonthlyInterest
CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
BEGIN
  FOR acc IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings') LOOP
    UPDATE Accounts
    SET Balance = Balance + (acc.Balance * 0.01)
    WHERE AccountID = acc.AccountID;

    DBMS_OUTPUT.PUT_LINE('Interest added to Account ' || acc.AccountID);
  END LOOP;
END;
/

-- Call the procedure
BEGIN
  ProcessMonthlyInterest;
END;
/
BEGIN
  DBMS_OUTPUT.PUT_LINE('ACCOUNTID | ACCOUNTTYPE | BALANCE');
  DBMS_OUTPUT.PUT_LINE('-------------------------------');
  FOR rec IN (SELECT * FROM Accounts ORDER BY AccountID) LOOP
    DBMS_OUTPUT.PUT_LINE(rec.AccountID || ' | ' || RPAD(rec.AccountType, 12) || ' | ' || rec.Balance);
  END LOOP;
END;
/

