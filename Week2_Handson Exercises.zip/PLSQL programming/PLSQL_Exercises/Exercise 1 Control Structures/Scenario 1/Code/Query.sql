-- Drop tables if they exist (for reruns)
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Customers';
  EXECUTE IMMEDIATE 'DROP TABLE Loans';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- Create Customers table
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE
);

-- Create Loans table
CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    InterestRate NUMBER(5,2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample data
BEGIN
  INSERT INTO Customers VALUES (1, 'Alice', TO_DATE('1950-05-15', 'YYYY-MM-DD')); -- Age 74
  INSERT INTO Customers VALUES (2, 'Bob', TO_DATE('1985-08-10', 'YYYY-MM-DD'));   -- Age 39
  INSERT INTO Customers VALUES (3, 'Charlie', TO_DATE('1960-01-01', 'YYYY-MM-DD')); -- Age 65

  INSERT INTO Loans VALUES (101, 1, 8.5);
  INSERT INTO Loans VALUES (102, 2, 7.0);
  INSERT INTO Loans VALUES (103, 3, 9.0);
END;
/

-- PL/SQL block: Apply 1% interest discount for customers above 60
BEGIN
  FOR cust IN (
    SELECT c.CustomerID, c.DOB, l.LoanID, l.InterestRate
    FROM Customers c
    JOIN Loans l ON c.CustomerID = l.CustomerID
  ) LOOP
    IF MONTHS_BETWEEN(SYSDATE, cust.DOB) / 12 > 60 THEN
      UPDATE Loans
      SET InterestRate = cust.InterestRate - 1
      WHERE LoanID = cust.LoanID;

      DBMS_OUTPUT.PUT_LINE('Discount applied to Customer ID ' || cust.CustomerID ||
                           ', Old Rate: ' || cust.InterestRate || 
                           ', New Rate: ' || (cust.InterestRate - 1));
    END IF;
  END LOOP;
END;
/

-- Check updated loan interest rates
SET LINESIZE 100;
COLUMN LoanID FORMAT 999;
COLUMN Name FORMAT A10;
COLUMN InterestRate FORMAT 99.99;

SELECT l.LoanID, c.Name, l.InterestRate
FROM Loans l
JOIN Customers c ON l.CustomerID = c.CustomerID;

