-- Drop tables if they already exist
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Loans';
  EXECUTE IMMEDIATE 'DROP TABLE Customers';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- Create Customers table
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100)
);

-- Create Loans table
CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    DueDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample data
BEGIN
  INSERT INTO Customers VALUES (1, 'Alice');
  INSERT INTO Customers VALUES (2, 'Bob');
  INSERT INTO Customers VALUES (3, 'Charlie');
  INSERT INTO Customers VALUES (4, 'Diana');

  INSERT INTO Loans VALUES (101, 1, SYSDATE + 10); -- within 30 days
  INSERT INTO Loans VALUES (102, 2, SYSDATE + 35); -- after 30 days
  INSERT INTO Loans VALUES (103, 3, SYSDATE + 5);  -- within 30 days
  INSERT INTO Loans VALUES (104, 4, SYSDATE - 1);  -- already due
END;
/

-- PL/SQL block to print reminders for loans due in next 30 days
BEGIN
  DBMS_OUTPUT.PUT_LINE(RPAD('Customer', 20) || RPAD('Loan ID', 10) || RPAD('Due Date', 20));
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

  FOR rec IN (
    SELECT c.Name, l.LoanID, l.DueDate
    FROM Customers c
    JOIN Loans l ON c.CustomerID = l.CustomerID
    WHERE l.DueDate BETWEEN SYSDATE AND SYSDATE + 30
    ORDER BY l.DueDate
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(
      RPAD(rec.Name, 20) ||
      RPAD(rec.LoanID, 10) ||
      TO_CHAR(rec.DueDate, 'DD-MON-YYYY')
    );
  END LOOP;
END;
/

/
