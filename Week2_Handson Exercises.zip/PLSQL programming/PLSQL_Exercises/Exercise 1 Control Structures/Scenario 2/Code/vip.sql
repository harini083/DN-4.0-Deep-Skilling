-- Drop table if it exists
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Customers';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- Create Customers table
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Balance NUMBER,
    IsVIP CHAR(1) DEFAULT 'N'
);

-- Insert sample data
BEGIN
  INSERT INTO Customers VALUES (1, 'Alice', 15000, 'N');
  INSERT INTO Customers VALUES (2, 'Bob', 8000, 'N');
  INSERT INTO Customers VALUES (3, 'Charlie', 11000, 'N');
  INSERT INTO Customers VALUES (4, 'Diana', 10000, 'N');
END;
/

-- PL/SQL block to update IsVIP
BEGIN
  FOR cust IN (SELECT CustomerID, Name, Balance FROM Customers) LOOP
    IF cust.Balance > 10000 THEN
      UPDATE Customers
      SET IsVIP = 'Y'
      WHERE CustomerID = cust.CustomerID;

      DBMS_OUTPUT.PUT_LINE('VIP Status set for ' || cust.Name || ' (Balance: $' || cust.Balance || ')');
    END IF;
  END LOOP;
END;
/

-- Display formatted output (width-aligned table)
BEGIN
  DBMS_OUTPUT.PUT_LINE(RPAD('CustomerID', 15) || RPAD('Name', 25) || RPAD('Balance', 20) || RPAD('IsVIP', 10));
  DBMS_OUTPUT.PUT_LINE(RPAD('-', 70, '-'));

  FOR rec IN (SELECT * FROM Customers ORDER BY CustomerID) LOOP
    DBMS_OUTPUT.PUT_LINE(
      RPAD(rec.CustomerID, 15) ||
      RPAD(rec.Name, 25) ||
      RPAD(rec.Balance, 20) ||
      RPAD(rec.IsVIP, 10)
    );
  END LOOP;
END;
/
