package com.cognizant.loan;

import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/loans")
public class loancontroller {

    @GetMapping("/{number}")
    public loan getLoanDetails(@PathVariable String number) {
        // Dummy static data
        return new loan("H00987987972342", "car", 400000, 3258, 18);
    }
}

